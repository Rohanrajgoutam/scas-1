
const loginView = (req, res, next) => {
    res.render('login');
}
const dashbordView = (req, res, next) => {
    res.render('dashbord');
}

const viewView = (req, res, next) => {
    res.render('view');
}

const outputView = (req, res, next) => {
    res.render('output');
}





module.exports ={
    loginView,
    viewView,
    outputView,
    dashbordView,
    
}